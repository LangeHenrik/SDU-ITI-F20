<?php
class DB_Config {
	
	protected $servername = 'localhost';
	protected $username = 'root';
	protected $password = 'C/|gkRgkYbJ8';
	protected $dbname = 'ahnai17';
}
	
	
	