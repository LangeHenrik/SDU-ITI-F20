<?php
class DB_Config {
	
	protected $servername = 'localhost';
	protected $username = 'root';
	protected $password = 'yan13641397589';
	protected $dbname = 'yaliu20';

	

}
	
	
	