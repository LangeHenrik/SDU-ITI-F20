<head>
    <link rel="stylesheet" href="../public/css/index_page_style.css">
</head>

<?php include '../app/views/partials/menu.php'; ?>
<?php include '../app/views/partials/foot.php'; ?>