<html>

<head>
    <script src="../js/js.js"></script>
    
</head>

<body>

<div>
    <h1 id="restrictMessage">please login</h1>
    <?php include '../app/views/partials/menu.php'; ?>
</div>



</body>