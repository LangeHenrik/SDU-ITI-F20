
 
 <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="application/javascript" src="js/script.js">   
</script>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="content">
<div>
<div class="topnav">
    <a href="welcome.php">Home</a>
    <a href="UploadImage.php">Upload</a>
    <a href="SelectData.php">User List</a>
    <a href="login.php">Log out</a>
    
  </div>

<div>
    <div class="wrapper">
    
    <div >
        <h1>Welcome Page</h1>
     
        <img id="rcorners1" src="img/pandas.jpg" style="max-width:100%;height:auto;">  
</div>
   
</div>
</body>


</html>
