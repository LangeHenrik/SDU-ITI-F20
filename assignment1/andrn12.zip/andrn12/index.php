<?php
session_start();
require "db_config.php";

$usern = "";
$_SESSION['userid'] = -1;

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $_SESSION['username'] = $usern = $_POST['username'];
    $_SESSION['password'] = $_POST['password'];

    //set user id
    require 'db_config.php';
    try{
        $connection = new PDO("mysql:host=$db_servername;dbname=$db_name", 
        $db_username, 
        $db_password, 
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        
        $stmt = $connection->prepare("SELECT * FROM users WHERE username = '$usern'");
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $result = $stmt->fetch();

        $_SESSION['userid'] = $result['userid'];
    }
    catch (PDOException $error) {
        //echo "Error: " . $error->getMessage();
        }
    $connection = null;

    header("Location: gallery.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Login</h2>
        <p>Please fill in your credentials to login.</p>
        <form method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" pattern=".{6,}" title="Must contain at least 6 characters" required> 
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            <p>Don't have an account? <a href="register.php">Sign up now</a>.</p>
        </form>
    </div>
</body>
</html>