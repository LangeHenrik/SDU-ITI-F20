<?php
  session_start();

?>
<!DOCTYPE html>
<head>
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Thank you to everyone for making Snapthat what it is today.</h1>
    </div>
    <p>
        <a href="Gallery.php" class="btn btn-warning">Return</a>
    </p>
    <div class="content">
        <h3>Thank you to all of our dear users</h3>
        <?php
            require 'db_config.php';
                try {
                $connection = new PDO("mysql:host=$db_servername;dbname=$db_name", 
                $db_username, 
                $db_password, 
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        
                $stmt = $connection->prepare("SELECT username FROM users");
                $stmt->execute();
                $stmt->setFetchMode(PDO::FETCH_ASSOC); 
                $result = $stmt->fetchAll();
                    foreach($result as $row) {
                        echo "<p>$row[username]</p>";
                    }
                } 
                catch (PDOException $error) {
                echo "Error: " . $error->getMessage();
                }
            $connection = null;
            ?>
    </div>
</body>
</html>