
<!DOCTYPE html>
<head>
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class='wrapper'>
    <p>
        <a href="gallery.php" class="btn btn-warning">Cancel Upload</a>
    </p>
    <div class="formContent" id="formContent">
        <h2>Choose a picture and join the fun!</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="title">Title</label><br/>
            <input type="text" name="title" id="title" placeholder="Write a Title for Your Image"><br/>

            <label for="image-name">Choose Your Image</label><br/>
            <input type="text" name="image-name" id="image-name" placeholder="image path"><br/>

            <label for="image-description" name="image-description" id="image-description">Image Description</label><br/>
            <textarea name="image-description" id="image-description" cols="30" rows="5" placeholder="Write a Description for Your Image"></textarea><br/>

            <button type="submit" value="upload" name="image-upload">UPLOAD</button>
        </form>
    </div>
        <?php
            session_start();

            if(array_key_exists('image-upload', $_POST)) {
                require 'db_config.php';
                try{
                    $conn = new PDO("mysql:host=$db_servername;dbname=$db_name", 
                    $db_username, 
                    $db_password, 
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
                    
                    //Filters input before use
                    $headerA = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
                    $headerXSS = htmlspecialchars($headerA);
                    
                    $descriptionA = filter_var($_POST['image-description'], FILTER_SANITIZE_STRING);
                    $descriptionXSS = htmlentities($descriptionA);
        
                    $imagepathA = filter_var($_POST['image-name'], FILTER_SANITIZE_STRING);
                    $imagepathXSS = htmlentities($imagepathA);
                    
                    $id = $_SESSION['userid'];
                    $stmt = $conn->prepare("INSERT INTO posts (posttitle, imagename, postdescription, poster) VALUES('$headerXSS', '$imagepathXSS', '$descriptionXSS', '$id')");
        
                    $stmt->execute(); 
                    $stmt->setFetchMode(PDO::FETCH_ASSOC); 
                } catch (PDOException $error) {
                    echo $error->getMessage();
                }
                $conn = null;
            }
        ?>
    </div>
    </body>
</html>