<?php 
    $db_servername = "localhost";
    $db_username = "root";
    $db_password = "drozton1";
    $db_name = "andrn12";
?>