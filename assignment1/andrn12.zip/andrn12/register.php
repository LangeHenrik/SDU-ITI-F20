<?php
session_start();
require "db_config.php";

$usern = "";
$_SESSION['userid'] = -1;

if($_SERVER["REQUEST_METHOD"] == "POST"){

    try{
        $connection = new PDO("mysql:host=$db_servername;dbname=$db_name", 
        $db_username, 
        $db_password, 
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));

        //Sanitizes input before inserting it into the Database
        $stmt = $connection->prepare("INSERT INTO users (username, email, password) VALUES(:username, :email, :pwd)");
        
        $user = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
        $userXSS = htmlspecialchars($user, ENT_QUOTES | ENT_SUBSTITUTE, 'utf-8');
        $stmt->bindParam(':username', $userXSS, PDO::PARAM_STR);

        $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
        $emailXSS = htmlspecialchars($email, ENT_QUOTES | ENT_SUBSTITUTE, 'utf-8');
        $stmt->bindParam(':email', $emailXSS, PDO::PARAM_STR);

        $pass = filter_var(password_hash($_POST['password'], PASSWORD_DEFAULT), FILTER_SANITIZE_STRING);
        $passXSS = htmlspecialchars($pass, ENT_QUOTES | ENT_SUBSTITUTE, 'utf-8');
        $stmt->bindParam(':pwd', $passXSS, PDO::PARAM_STR);

        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        $_SESSION['username'] = $usern = $_POST['username'];
        $_SESSION['password'] = $_POST['password'];
            
        $stmt = $connection->prepare("SELECT * FROM users WHERE username = '$usern'");
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $result = $stmt->fetch();
        
        $_SESSION['userid'] = $result['userid'];
       
        header("Location: gallery.php");
    }
    catch (PDOException $e){
        echo $e->getMessage();
    }
    $connection = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Sign Up</h2>
        <p>Please fill in your credentials to create account.</p>
        <form method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" pattern="[a-zA-Z0-9].{3,}" title="Only lower case, uppercase and numbers allowed, must be 3 characters long" required>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" pattern=".{6,}" title="Must contain at least 6 characters" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2, 4}$" required>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Sign Up">
            </div>
            <p>Already have an account? <a href="index.php">Login now</a>.</p>
        </form>
    </div>
</body>
</html>