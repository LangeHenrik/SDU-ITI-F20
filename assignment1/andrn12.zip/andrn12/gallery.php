<?php
    session_start();
    //check if user is in db
    $usern = $_SESSION['username'];

    require 'db_config.php';
    try{
        $connection = new PDO("mysql:host=$db_servername;dbname=$db_name", 
        $db_username, 
        $db_password, 
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        
        $stmt = $connection->prepare("SELECT * FROM users WHERE username = '$usern'");
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $result = $stmt->fetch();

        if(!$result['userid'] <= 0){
            header("Location: login.php");
        } else {
            $_SESSION['userid'] = $result['userid'];
        };
    }
    catch (PDOException $error) {
        //echo "Error: " . $error->getMessage();
        }
    $connection = null;
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Hi <b><?php echo htmlspecialchars($_SESSION['username']); ?></b>. Welcome to Snapthat.</h1>
    </div>
    <p>
        <a href="userlist.php" class="btn btn-warning">See Users</a>
        <a href="upload.php" class="btn btn-warning">Upload</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>

    <div class="wrapper">
        <div class="content">
                
            <h3>Here are some user pictures</h3>
            <?php
                require 'db_config.php';
                try{
                    $connection = new PDO("mysql:host=$db_servername;dbname=$db_name", 
                    $db_username, 
                    $db_password, 
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        
                    $stmt = $connection->prepare("SELECT * FROM posts");
                    $stmt->execute();
                    $stmt->setFetchMode(PDO::FETCH_ASSOC);
                    $result = $stmt->fetchAll();
                    //print_r($result);
                    echo "<div>";
                        foreach($result as $row){
                            echo "<br><div id=formContent><br>$row[posttitle]<br>";
                            echo "<img src='$row[imagename]' alt='User Picture' height='400' width='400'></img><br>";
                            //echo '<img src="doug.jpg" alt="User Picture" height="400" width="400"/><br/>';
                            echo "<p>$row[poster]: $row[postdescription]</p><br>";
                            echo "</div>";
                        }
                    echo "</div>";
                }
                catch (PDOException $error) {
                    //echo "Error: " . $error->getMessage();
                }
                $connection = null;
            ?>

        </div>
    </div>
</body>
</html>