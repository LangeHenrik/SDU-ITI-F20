DROP DATABASE IF EXISTS andrn12;
CREATE DATABASE andrn12;
USE andrn12;

CREATE TABLE users (
    userid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(200) NOT NULL,
    created_at datetime,
    email VARCHAR(100) NOT NULL
);

CREATE TABLE posts (
    postid INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    posttitle VARCHAR(50) NOT NULL,
    imagename VARCHAR(200),
    postdescription VARCHAR(250) NOT NULL,
    poster INT,
    FOREIGN KEY (poster) REFERENCES users(userid)
);

INSERT INTO users (userid, username, password, email, phone) VALUES
(1, 'doug', '$2y$10$YaDyw44VE7CScC7crZ4ybOb1de9jC.b5YomdMvIozY2L9uZVrq5Ve', 'doug@dimmsdale.com'),
(2, 'bob', '$2y$10$YaDyw44VE7CScC7crZ4ybOb1de9jC.b5YomdMvIozY2L9uZVrq5Ve', 'bob@bobo.bom'),
(3, 'admin', '$2y$10$5hZxcqnd35cbq2UnswYfx.7ZcfveMS0.EhEnD.qfKr8yLu/flIDXi', 'admin@root.com');

INSERT INTO posts (postid, posttitle, imagename, postdescription, poster) VALUES
(1, 'Doug Dimmadome at Burger King','doug.jpg', 'Buying fast food with my favorite hat', 1),
(2, 'Hello there', 'lazy-town-t.jpg', 'Nice hat', 2),
(3, 'Surprised', 'chicken.jpg', 'I am very surprised');