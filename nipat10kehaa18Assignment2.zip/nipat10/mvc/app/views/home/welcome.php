<?php include '../app/views/partials/menu.php'; ?>

<body>
<div class="main" align="center">

<!-- Simple Welcome message-->
<h1>Welcome</h1>

</div>
</body>
<?php include '../app/views/partials/foot.php'; ?>