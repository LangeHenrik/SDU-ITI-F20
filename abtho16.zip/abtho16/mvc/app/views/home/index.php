<?php include '../app/views/partials/newUserNav.php'; ?>
<link rel="stylesheet" href="/abtho16/mvc/public/content/css/login_Reg.css">


<div>
    
 <div class ="bg">
<br>
<hr><hr><hr><hr><hr><hr><hr><hr>
<br>
    <h1>Hello! welcome to my site </h1>
    <div>
    <br><br>
<hr><hr><hr><hr><hr><hr><hr><hr>
 
</div>
<?php include '../app/views/partials/foot.php'; ?>

<?php

