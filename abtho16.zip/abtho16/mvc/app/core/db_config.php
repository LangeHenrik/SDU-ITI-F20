<?php
class DB_Config {

    protected $servername = '127.0.0.1';
    protected $username = 'root';
    protected $password = 'root';
    protected $dbname = 'abtho16';

}


