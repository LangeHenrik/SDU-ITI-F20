<?php

class MathService {

    public function add ($a, $b) {
        return $a + $b;
    }

}