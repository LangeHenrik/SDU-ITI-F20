name of branch = josan20
name of folder with project = project1
database = migration.sql

for database management is used phpmyadmin

start database:
    brew services start mariadb
    mysql.server start
    mysql -u root -p