<?php
   $DB_SERVER = 'localhost';
   $DB_USERNAME = 'root';
   $DB_PASSWORD = '1234';
   $DB_DATABASE = 'jumar18_micpe18_mihen13';
?>
