<?php

class db_config {
    public static $db_hostname = "127.0.0.1";
    public static $db_username = "root";
    public static $db_password = "admin";
    public static $db_name = "aldus17";
}
